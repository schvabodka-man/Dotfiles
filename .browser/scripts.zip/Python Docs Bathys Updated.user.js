// ==UserScript==
// @name          Python Docs Bathys Updated
// @namespace     http://userstyles.org
// @description	  <p>Dark Bathys theme (inspired by the GT Deepdark theme) for the Python Docs, updated with less aggressive colors and other tweaks.</p>
// @author        torrentails
// @homepage      https://userstyles.org/styles/128563
// @run-at        document-start
// @version       0.20160603090301
// ==/UserScript==
(function() {var css = "";
css += [
		"/*",
		" * Style:   Bathys Updated",
		" * Site:    Python Docs",
		" * Author:  torrentails",
		" * License: CC-BY-SA",
		" * File:    python/docs.css",
		" */",
		"",
		"@namespace url(http://www.w3.org/1999/xhtml);"
	].join("\n");
if (false || (document.domain == "docs.python.org" || document.domain.substring(document.domain.indexOf(".docs.python.org") + 1) == "docs.python.org"))
	css += [
		"body {",
		"    background-color: #111;",
		"}",
		"",
		"div.body",
		"{",
		"    background: #161616 url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAH0lEQVQI12NgYGD4LycnB8cMKioqqAJwBlQlXACmEgCsthUB9mCnuQAAAABJRU5ErkJggg==\") repeat;",
		"    color: #aaa;",
		"}",
		"",
		"div.document ",
		"{",
		"    background: #012028;",
		"}",
		"",
		"div.body h1, div.body h2, div.body h3, div.body h4, div.body h5, div.body h6",
		"{",
		"    background: none;",
		"    color: #3776A3;",
		"}",
		"",
		"div.related,",
		"div.sphinxsidebar ",
		"{",
		"    background-color: #111;",
		"}",
		"",
		"div.sphinxsidebar input {",
		"    border: 1px solid #333;",
		"}",
		"",
		"div.note {",
		"    background-color: #111;",
		"    border-color: #000;",
		"}",
		"",
		"div.related:first-child {",
		"    border-color: #AAA;",
		"}",
		"",
		"div#sidebarbutton {",
		"    background-color: #000 !important;",
		"}",
		"",
		"a {",
		"    color: #4983AB !important;",
		"}",
		"",
		"tt",
		"{",
		"    background: none;",
		"}",
		"",
		"pre ",
		"{",
		"    background: #222;",
		"    color: #AAA;",
		"}",
		"",
		".highlight .go /*output*/",
		"{",
		"    color: #AAA;",
		"}",
		"",
		".highlight .gt, .highlight .nf /*tracebacks*/",
		"{",
		"    color: #4772D1;",
		"}",
		"",
		".highlight .nd {",
		"    color: #aaa;",
		"}",
		"",
		"table.docutils thead tr {",
		"    background-color: #322;",
		"}",
		"",
		"table.docutils tbody tr.row-even {",
		"    background-color: #222;",
		"}",
		"",
		"table.docutils tbody tr.row-odd {",
		"    background-color: #181818;",
		"}",
		"",
		"table.docutils td, table.docutils th",
		"{",
		"    background-color: inherit;",
		"    border-color: #333;",
		"}",
		"",
		"select, input ",
		"{",
		"    background-color: #111;",
		"    color: #AAA;",
		"}",
		"",
		"input[name=\"q\"] {",
		"    background-color: #333;",
		"}",
		"",
		"select",
		"{",
		"    border-color: #000;",
		"}",
		"",
		"dt:target, .highlight {",
		"    background-color: #7C6600;",
		"    color: #EEE;",
		"}",
		"",
		"div.warning,",
		".deprecated, .deprecated-removed {",
		"    background-color: #211;",
		"}",
		"",
		"div.seealso {",
		"    background-color: #221;",
		"}",
		"",
		"code {",
		"    background-color: inherit !important;",
		"}"
	].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
