// ==UserScript==
// @name          Steam - fade owned items
// @namespace     http://userstyles.org
// @description	  It fades items that you already have (Steam does it by default, but it's not enough, at least for me).
// @author        vhs
// @homepage      https://userstyles.org/styles/115156
// @include       http://steampowered.com/*
// @include       https://steampowered.com/*
// @include       http://*.steampowered.com/*
// @include       https://*.steampowered.com/*
// @run-at        document-start
// @version       0.20161125033452
// ==/UserScript==
(function() {var css = [
	".MoreContentCap {",
	"    opacity: 1 !important;",
	"}",
	"",
	".ds_flagged.ds_owned, .ds_owned, .sih_owned {",
	"	opacity: 0.1 !important;",
	"    transition: opacity 0.4s !important;",
	"}",
	"",
	".ds_flagged img {",
	"    opacity: 1 !important;",
	"}",
	"",
	".ds_flagged.ds_owned:hover, .ds_owned:hover, .sih_owned:hover {",
	"	opacity: 1 !important;",
	"}",
	"",
	".ds_owned_flag, .ds_wishlist_flag {",
	"    display: none;",
	"}",
	"",
	".ds_wishlist.ds_flagged {",
	"    background-color: rgba(0, 245, 255, 0.2) !important;",
	"}"
].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
