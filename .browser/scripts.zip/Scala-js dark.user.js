// ==UserScript==
// @name          Scala-js dark
// @namespace     http://userstyles.org
// @description	  Dark theme for scalajs
// @author        uromysitisis
// @homepage      https://userstyles.org/styles/146959
// @include       http://www.scala-js.org/*
// @include       https://www.scala-js.org/*
// @include       http://*.www.scala-js.org/*
// @include       https://*.www.scala-js.org/*
// @run-at        document-start
// @version       0.20170821185253
// ==/UserScript==
(function() {var css = [
	"body",
	"{",
	"    background-color: #222;",
	"}",
	"",
	"body,",
	"p",
	"{",
	"    color: #e0eeff;",
	"}",
	"",
	"a",
	"{",
	"    color: #58b2ff;",
	"}",
	"",
	".table-striped",
	"{",
	"    background: white;",
	"    color: black;",
	"}"
].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
