// ==UserScript==
// @name          RuTracker Minimal Dark-Blue v1.1 beta
// @namespace     http://userstyles.org
// @description	  Тема находится в состоянии Beta!
// @author        Desigher
// @homepage      https://userstyles.org/styles/137559
// @include       http://rutracker.cr/*
// @include       https://rutracker.cr/*
// @include       http://*.rutracker.cr/*
// @include       https://*.rutracker.cr/*
// @include       http://rutracker.org/*
// @include       https://rutracker.org/*
// @include       http://*.rutracker.org/*
// @include       https://*.rutracker.org/*
// @include       http://rutracker.net/*
// @include       https://rutracker.net/*
// @include       http://*.rutracker.net/*
// @include       https://*.rutracker.net/*
// @include       http://rutracker.nl/*
// @include       https://rutracker.nl/*
// @include       http://*.rutracker.nl/*
// @include       https://*.rutracker.nl/*
// @include       http://rutracker.net/*
// @include       https://rutracker.net/*
// @include       http://*.rutracker.net/*
// @include       https://*.rutracker.net/*
// @run-at        document-start
// @version       0.20170819062317
// ==/UserScript==
(function() {var css = "";
if (false || (document.domain == "rutracker.cr" || document.domain.substring(document.domain.indexOf(".rutracker.cr") + 1) == "rutracker.cr") || (document.domain == "rutracker.org" || document.domain.substring(document.domain.indexOf(".rutracker.org") + 1) == "rutracker.org") || (document.domain == "rutracker.net" || document.domain.substring(document.domain.indexOf(".rutracker.net") + 1) == "rutracker.net") || (document.domain == "rutracker.nl" || document.domain.substring(document.domain.indexOf(".rutracker.nl") + 1) == "rutracker.nl"))
	css += [
		":root {",
		"  --color1: #1d1d24; /*BG*/",
		"  --color2: #848491; /*TEXT*/",
		"  --color3: #a6a6b5; /*Briter TEXT*/",
		"  --color4: #23232d;",
		"  --color5: #2c2c36;",
		"  --color6: #77babc; /*Link*/",
		"  --color7: #d2f1f2; /*Active link*/",
		"  --color8: rgba(90, 90, 99, 0.25);",
		"  --color9: rgba(35,35,45,0.9);",
		"  --color10: rgba(90, 90, 99, 0.15);",
		"  --color11: rgba(35, 35, 45, 0.5);",
		"}",
		"",
		"*::-webkit-scrollbar {",
		"    width: 15px !important;",
		"    height: 10px !important;",
		"    background:  var(--color4) !important;",
		"    border: 1px solid var(--color5) !important;",
		"}",
		"",
		"*::-webkit-scrollbar-thumb {",
		"    min-height: 28px !important;",
		"    background: var(--color5) !important;",
		"}",
		"",
		"/*====================== bg ===========================*/",
		"",
		"#page_container, body, .news_title, optgroup option, .sp-body, select, textarea, input, .q, td.cat.pad_2, #body_container, .menu-a {",
		"    background-color:var(--color1) !important;",
		"    background-image: none;",
		"}",
		"",
		".site-nav, .topmenu, .news_date, .row1, .row1 td, .sb2-block, .row4, .row4 td, optgroup, .row5, .row5 td, .sp-wrap, table.forumline, .menu-a a:hover {",
		"    background-color:var(--color4) !important;",
		"    background-image: none;",
		"}",
		"",
		".cat_title, .bordered th, .forumline th, .cat, td.cat, td.catTitle, td.catHead, td.catBottom, tr.hl-tr:hover td, .row3, .row3 td, .thHead, option:hover, input[type=\"submit\"], div.t-tags span, .spaceRow, #cse-search-btn-top {",
		"	background-color:var(--color5) !important;",
		"    background-image: none;",
		"}",
		"",
		"input[type=\"submit\"]:hover {background-color:var(--color8) !important;}",
		"input[type=\"submit\"]:active {background-color:var(--color9) !important;}",
		"div.t-tags span:hover {background:var(--color8) !important;}",
		"",
		".f, .fieldsets div>p, .fieldsets div, a.med, .a-like.med, a.small.tr-dl, p.tCenter a.gen, a.gen, a.med, a.small, a.gensmall, .gen, .med, .gensmall, .small {",
		"    background: transparent;",
		"}",
		"",
		".folded, .folded2 {background-color:var(--color4) !important;}",
		"",
		".row2, .row2 td {background-color:var(--color11) !important;}",
		"",
		"",
		"/*====================== color ===========================*/",
		"",
		"#page_container, body, .gen, .med, .small, .gensmall, .topmenu, .news_title, .site-nav, .news_date, .row1, .row1 td, .sb2-block, legend, optgroup option, span.brackets-pair, .sp-head span, .sp-body, span.p-color, select, textarea, input, .new .dot-sf, .q, .c-head, .q-head, .q-head span, div.t-tags span, .poster_info em {",
		"    color:var(--color2) !important;",
		"}",
		"",
		"#latest_news h3, .cat_title a, .forumline th, a.tLink, .maintitle, .pagetitle, .catTitle, optgroup, a:hover .brackets-pair, #sidebar1 h3, #idx-sidebar2 h3, td.topicSep, .poster_info p {",
		"    color:var(--color3) !important;",
		"}",
		"",
		"a, #latest_news a, .a-like, .nick-author, .nick-author a, .nick, .nick a {",
		"    color:var(--color6) !important;",
		"}",
		"",
		"a:hover, a:active, a:focus, #latest_news a:hover, .site-nav a:hover, .site-nav a:active, .a-like:hover {",
		"	color:var(--color7) !important;",
		"}",
		"",
		".dlComplete, .seed, .seedmed, .seedsmall {color: #7CB342;}",
		".dlDown, .leech, .leechmed, .leechsmall {color: #ef5350 !important;}",
		"[style=\'color: brown;\'] {color: #e57373 !important;}",
		"",
		"",
		"/*====================== Borders ===========================*/",
		"",
		"input, select, .menu-a {",
		"    border-radius: 2px;",
		"}",
		".topmenu {border-radius: 6px;}",
		"    ",
		"",
		".news_date, .sb2-block, .forums td.row1, .cat_title, table.bordered, .bordered th, .bordered td, table.borderless .bordered th, table.borderless .bordered td, fieldset, .forumline th, .forumline td, table.forumline, table.topic, .topic .td1, .topic .td2, .topic .td3, .post_head, .post_btn_2, .c-body, .q, .sp-wrap, .sp-head, .sp-body, hr, #fs-main, select, textarea, input, .menu-a{",
		"    border-color: var(--color5) !important;",
		"}",
		"",
		"div.t-tags span:hover, div.t-tags span {",
		"    border-color: var(--color8) !important;",
		"}",
		"",
		"option {border-color: var(--color4) !important;}",
		"",
		".bw_TRL {border-width: 0px !important;}",
		"",
		"textarea, input  {border: solid 1px;}",
		"",
		".news_title {background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZAAAAABCAYAAADw8vieAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA0ppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NTgxNjIxQzdEODBCMTFFNjhBMzFBMjYyQTIwRTc4OUMiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NTgxNjIxQzZEODBCMTFFNjhBMzFBMjYyQTIwRTc4OUMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo0YmUzNjMxYS1kODBiLTExZTYtYTY0NC1kYWY0YzIxN2MyZTYiIHN0UmVmOmRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo0YmUzNjMxYS1kODBiLTExZTYtYTY0NC1kYWY0YzIxN2MyZTYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4SyfCzAAAAUElEQVR42mJUU1P7zwABMJoYNrHyxMiRooYUmlI1hMSoKY+PTQ09lKilBZ+WaqgtNhB20jMMacknVy018wIt8zC1yxxyaErVkFvGg9kAAQYABTL/dKVechgAAAAASUVORK5CYII=) no-repeat left top;}",
		"",
		"#sidebar1 h3, #idx-sidebar2 h3 {background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAABCAYAAACbv+HiAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA0ppVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6OUJCOUYxQTVEODBCMTFFNjgwM0M4NDhDQjg1MURBMDIiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6OUJCOUYxQTREODBCMTFFNjgwM0M4NDhDQjg1MURBMDIiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo0YmUzNjMxYS1kODBiLTExZTYtYTY0NC1kYWY0YzIxN2MyZTYiIHN0UmVmOmRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDo0YmUzNjMxYS1kODBiLTExZTYtYTY0NC1kYWY0YzIxN2MyZTYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4nWvgUAAAAQ0lEQVR42mJUU1P7z8DAAMIMUBqdjY3/n0R5GP5Hojwp/H94xLDJ04ImVY4a6sl1DzVpUuOCHD6paYnctIuSDwACDABPAr91m4DQFgAAAABJRU5ErkJggg==) no-repeat left bottom;}",
		"",
		"/*====================== hide ===========================*/",
		"",
		"#logo, #bn-idx-marathonbet, .bn-idx, #bn-bot-wrap, #bn-idx-3, .bn-idx, #idx-sidebar2 iframe, #adriver-240x120, table.w100 iframe, td.bn-topic {",
		"    display: none;",
		"}",
		"",
		".topmenu {",
		"    border: none;",
		"}",
		"",
		"",
		"/*====================== sizes ===========================*/",
		"",
		".topmenu #search-text, .topmenu #search-text-guest, form#login-form-quick [type=\'text\'], form#login-form-quick [type=\'password\'] {",
		"    padding: 0px 12px;",
		"}",
		".topmenu #search-menu {padding: 0px 5px; margin-right: 2px;}",
		".topmenu #search-submit .topmenu #cse-search-btn-top {width: 70px !important;}",
		".topmenu input, .topmenu select {height: 30px;}",
		".cat_title {padding: 8px 8px 7px;}",
		"",
		"/*====================== miscellaneous ===========================*/",
		"",
		"#main-nav {",
		"    background: url(\'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAE8AAAATCAYAAADReFAKAAABS2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxMzggNzkuMTU5ODI0LCAyMDE2LzA5LzE0LTAxOjA5OjAxICAgICAgICAiPgogPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIi8+CiA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgo8P3hwYWNrZXQgZW5kPSJyIj8+IEmuOgAAA1hJREFUWIXtWO2Rm0AM1V4HtMCVQAukBLdAC7gEUgIpgSvBV4IpAZeAS3j5YWl5K5Y73w1kkpnoD3hXKz1p9YVFNghABaAHcMVCFwDN1pm/kQC0AOY/ghtAAWBQZ11VeQ2gUxAA0B8OZEdSO+ajlVTqoHhT6rRB32uKwtOhYHYkA3ykgoIiq9pSTGk8HAZmR9KAAIBpb9kv9D6ISCEi5xDCqIpL3bsR312fxd5gDqJan+97C34ReaSjKrmFEH7SvqUmKzan3eWLpPUTALrvgP0mmQ3jIdK1i8J3JEpRq3+WAiveJ/WYvN7k7WPBpj7G+6VMeQobgDJXUHld362ZAMDV8dYavfHsR3oAnCgK2ycwJvI/sKNmJ+ExavFltQAmZJqdnq2I73NsABplvLj1zhyFZVaCRmnheJNozERsizVZtA8KvPVO1wub6MygOAbi4dEKoMZAmE1+1O2cxjraZ7DZ4ayXSTErzd0Yp0aFNMKajLxOf1tUTAT+4uTamdnh6IgvrpnRLigmdYCNYFEPYWf5/RPYCgANd1t2SCNLY3ijrbX3Raw23LVLs4PfDWRG3pmeJfMrXfXMKCKvkjaoN8Ip8mh0Z+W3hlcTbyciPzwu1WEYDN/4BLZGREauRVyz4heG/o5hLI5or8+d1TW7VU6pQqPlRNFT6h6vWR2yCGC5RlYeysxeB1ejnY5JfTCTvZvYdL9nQRUBL1ixMXvgGd4T0pRtiS+RRw4tQbWV9sxRXOhnlut0+VppX0IzlvrrecwmS/cZacOoNrCdoJf1IiISQhhDCDYIc1ezULUZybfvxvFyytqgXTgeo1J1mkwuD5FfDSplSSuTEbEQdnF7N1nSztfrhp43EXkNIYyKt9QSlMNWhxB+ZbAmXZY/yZIxQ9c46oB1Zyy8PHeztb5b2tvvhvhttFiNUxSJUZeucwO7Im0cBfGYXt8o+0+wbc+3dMCPLjF18UiLqwNqxsZ/XvCofx05Na6RXKuRxntBSlbPjIynIbkDHunUYRmtog1YUtf2JuKZVZatNx9h23ScA+lvpCSw/l8XYKmPDfG0tDbzmosU2+uwFOvkPzgydkL6xcPR3iONrjbDN6gtBdKLWg3POWzfcp7uFXBT/L9O5si9hDW5W/hPa/oNc26mo8iZa+cAAAAASUVORK5CYII=\') 29px 9px no-repeat;",
		"}",
		"",
		"a.topictitle:hover, a.torTopic:hover, a.tLink:hover {text-decoration:none !important;}",
		"",
		"select, textarea, input {outline:none !important;}",
		"div.t-tags span {text-shadow: none;}",
		".news_date {border-radius: 7px 0px 0px 0px;}",
		"",
		".site-nav {padding: 8px 0 6px 129px;}",
		".topmenu {margin: 12px 10px 0; padding: 8px 16px;}",
		"",
		"#page_footer a img, .nav-natz a img {opacity: 0.15;}",
		"#page_footer a:hover img, .nav-natz a:hover img  {opacity: 1;}",
		"",
		"#main-nav {position: fixed; z-index: 999; top: 0px; width: 100%; box-shadow: 0px 6px 15px rgb(29, 29, 36);}",
		"#page_header {margin-top: 50px;}"
	].join("\n");
if (false || (document.domain == "rutracker.net" || document.domain.substring(document.domain.indexOf(".rutracker.net") + 1) == "rutracker.net"))
	css += [
		"body{",
		"    transform: scaleX(1) !important;",
		"  }"
	].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
