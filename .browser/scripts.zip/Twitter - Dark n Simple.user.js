// ==UserScript==
// @name          Twitter - Dark n Simple
// @namespace     http://userstyles.org
// @description	  Changes the website to be nice and dark, easy for the eyes.
// @author        Gibbu
// @homepage      https://userstyles.org/styles/128569
// @include       https://twitter.com/*
// @include       https://amp.twimg.com*
// @include       https://api.twitter.com*
// @run-at        document-start
// @version       0.20171028030232
// ==/UserScript==
(function() {var css = [
	"@font-face {",
	"    font-family: \'Comfortaa\';",
	"    font-style: normal;",
	"    font-weight: 400;",
	"    src: local(\'Comfortaa Regular\'), local(\'Comfortaa-Regular\'), url(https://fonts.gstatic.com/s/comfortaa/v10/qLBu5CQmSMt1H43OiWJ77VtXRa8TVwTICgirnJhmVJw.woff2) format(\'woff2\');",
	"    unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215;",
	"  }",
	"  @font-face {",
	"    font-family: \'Open Sans\';",
	"    font-style: normal;",
	"    font-weight: 400;",
	"    src: local(\'Open Sans Regular\'), local(\'OpenSans-Regular\'), url(https://fonts.gstatic.com/s/opensans/v14/cJZKeOuBrn4kERxqtaUH3VtXRa8TVwTICgirnJhmVJw.woff2) format(\'woff2\');",
	"    unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215;",
	"  }",
	"  @font-face {",
	"    font-family: \'Roboto\';",
	"    font-style: normal;",
	"    font-weight: 400;",
	"    src: local(\'Roboto\'), local(\'Roboto-Regular\'), url(https://fonts.gstatic.com/s/roboto/v16/CWB0XYA8bzo0kSThX0UTuA.woff2) format(\'woff2\');",
	"    unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215;",
	"  }",
	"",
	"",
	"",
	"  :root {",
	"    ",
	"  --bg0: #090909;",
	"  --bg1: #111;",
	"  --bg2: #151515;",
	"  --bg3: #1c1c1c;",
	"  --bg4: #222;",
	"  --bg5: #252525;",
	"  --bg6: #2c2c2c;",
	"    ",
	"  --colourF: #fff;",
	"  --colourE: #eee;",
	"  --colourD: #ddd;",
	"  --colourC: #ccc;",
	"  --colourB: #bbb;",
	"    ",
	"}",
	"",
	"  * {font-family: \'Roboto\' !important; font-weight: 400 !important;}",
	"  html, body, #doc, #page-outer, .ProfilePage.is-editing .ProfilePage-editingOverlay {background: var(--bg0) !important;}",
	"  .global-nav-inner, .module .flex-module, .Trends, .stream-item:not(.no-header-background-module), .ProfileSidebar .TweetImpressionsModule, .ProfileSidebar .ProfileLifelineInfo, .ProfileSidebar .RelatedUsers, .MomentGuideNavigation, .MomentCapsuleSummary--hero:hover, .MomentCapsuleSummary--portrait:hover, .MomentCapsuleItemTweet--withText, .hovercard .profile-social-proof, .modal-header, .modal-footer, .modal-body, .DashboardProfileCard, .DashboardProfileCard-avatarLink, .DashboardProfileCard-avatarImage, .modal-content, .permalink, .SignupCallOut {background: var(--bg1); border-color: var(--bg1);} ",
	"  .tweet:hover {background: var(--bg2);}",
	"  .home-tweet-box, .LiveVideo-tweetBox, .RetweetDialog-commentBox {background: var(--bg2);}",
	"  .top-timeline-tweetbox .timeline-tweet-box, .MomentCapsuleSummaryGroup:nth-child(2n+3), .MomentCapsuleCover-media {border-color: var(--bg2);}",
	"  .tweet {border-bottom-color:  var(--bg3);}",
	"  .wtf-module .UserSmallListItem {border-bottom-color: var(--bg3);}",
	"  .new-tweets-bar, .ProfileAvatarEditing, .global-nav .search-input, .PollingCardComposer, .ThreadedConversation--header, .TwitterCard-container, .NotificationsHeadingContent, .content-header, .content-no-header, .modal-header, .DMTypeaheadSuggestions-item:hover, .DMTokenizedMultiselectSuggestion.is-highlighted, .DMButtonBar, .MomentCapsuleItemTweet .QuoteTweet, .modal-footer, .MomentMakerRecommendations, .MomentMakerCapsuleCover-empty, li.stream-item.highlighted, .DMInboxItem.is-unread, .AdaptiveFiltersBar {background: var(--bg3); border-color: var(--bg3);}",
	"  .new-tweets-bar:hover, .MomentCapsuleItemTweet--withText .QuoteTweet:active, .MomentCapsuleItemTweet--withText .QuoteTweet:focus, .MomentCapsuleItemTweet--withText .QuoteTweet:hover, .ActivityItem:not(.has-clickAction) .QuoteTweet--slim:hover, .QuoteTweet:hover, .TwitterCard-container--clickable:hover, .MomentMakerRecommendations-module, .block-dialog .submit-section, .phone-deletion-dialog .submit-section, .DMDivider::before, .Tombstone, .advanced-search .chk-inner, .advanced-search select, .advanced-search input[type=\"text\"] {background: var(--bg4); border-color: var(--bg4);}",
	"  .EdgeButton--secondary {background: transparent;}",
	"  .EdgeButton--secondary:hover, .RichEditor {background: var(--bg3);}",
	"  textarea, div[contenteditable] {background: var(--bg3); border-color: var(--bg3);}",
	"  .RichEditor, .TweetBoxAttachments {border-color: var(--bg3);}",
	"  .ProfileCanopy-navBar, .ProfileNav-item--userActions, .ProfileAvatar, .u-bgUserColorLightest, .u-bgUserColorLighter, .permalink-tweet, .permalink-tweet:hover, .DMConversation-scrollContainer, .PermalinkOverlay-spinnerContainer, .RetweetDialog-footer, .modal .modal-tweet, .DMActivity-body, .MomentFloatingMenu, .permalink .inline-reply-tweetbox, .ListCreationModule, .ProfileUserMomentsTimeline .MomentCapsuleSummary, .ProfileUserMomentsTimeline .GridTimeline-items.has-items, .MomentMakerPage-content, .MomentMakerCoverDialog .modal-body, .MomentMakerCoverCropper, .MomentMakerCropBeforePublishDialog .modal-body, .MomentMakerPage-mask, #global-tweet-dialog .modal-tweet-form-container, #Tweetstorm-dialog .modal-body, .TwitterCard .MomentCard, .conversation-module .conversation-tweet-item .tweet:hover, #global-tweet-dialog .modal-tweet .tweet:hover, #global-tweet-dialog .modal-tweet .tweet, #Tweetstorm-dialog .modal-tweet .tweet:hover, #Tweetstorm-dialog .modal-tweet .tweet, .DMDivider, .SidebarFilterModule, .search {background: var(--bg2) !important; border-color: var(--bg2)}",
	"  .u-textInheritColor {color: var(--colourB) !important; font-weight: bold !important;}",
	"  .QuoteTweet {border-color: var(--bg3); background: var(--bg3)}",
	"  .wtf-module .import-prompt, .Footer--blankBackground {display: none;}",
	"  .recap-header {border-color: var(--bg3); color: var(--colourF)}",
	"  .stream-item + .stream-item.separated-module:not(.no-header-background-module) {border-top-color: var(--bg3)}",
	"  .ActivityItem {border-color: var(--bg3)}",
	"  .stream-end-inner, .stream-end-item, .stream-end, .stream-loading, .stream-placeholder, .ProfileHeading-content, .TwitterCard .PollXChoice-pollWrapper, .dropdown-menu, .ThreadedConversation-moreReplies, .DMActivity-header, .TokenizedMultiselect-inputContainer {background: var(--bg3); border-color: var(--bg3)}",
	"  .stream-end-inner .Icon--large {filter: invert(1); -webkit-filter: invert(1)}",
	"  .stream-item + .stream-item.separated-module:not(.no-header-background-module), .stream-item.separated-module + .stream-item:not(.no-header-background-module), .PromptbirdPrompt-streamItem.separated-module + .stream-item:not(.no-header-background-module), .MomentsPermalinkPage-related {border-top-color: var(--bg3)}",
	"  .ProfileCard {background: var(--bg1); border-color: var(--bg1);}",
	"  .EdgeButton--tertiary {background: var(--bg4); border-color: var(--bg4); color: var(--colourF)}",
	"  .EdgeButton--tertiary:hover {background: var(--bg6); border-color: var(--bg6); color: var(--colourF)}",
	"  input {color: var(--colourB) !important; background: var(--bg3); border-color: var(--bg3)}",
	"  .u-borderUserColorLight, .u-borderUserColorLightFocus:focus, .u-borderUserColorLightHover:hover, .u-borderUserColorLightHover:focus, .DirectMessage--received .DirectMessage-message.with-tweet .DirectMessage-attachmentContainer, .u-borderUserColorLighter {border-color: var(--bg3) !important;}",
	"  .PollingCardComposer {box-shadow: inset 0 1px 0 var(--bg5)}",
	"  .PollingCardComposer .PollingCardComposer-pollDuration {border-color: var(--bg5)}",
	"  .RichEditor.is-fakeFocus ~ .TweetBoxAttachments {border-color: var(--bg3); box-shadow: none;}",
	"  .dropdown-menu .typeahead-items li > a:focus, .dropdown-menu .typeahead-items li > a:hover, .dropdown-menu .typeahead-items .selected, .dropdown-menu .typeahead-items .selected a, .ThreadedConversation-showMoreThreads, .global-nav .search-input:focus, .global-nav .search-input.focus, .TwitterCard .EdgeButton--secondary:hover, .message {background: var(--bg4) !important;}",
	"  .typeahead .dropdown-inner > .has-results ~ .has-results, .typeahead .dropdown-inner > .has-items ~ .has-items, .dropdown-divider {border-color: var(--bg6)}",
	"  .dropdown-caret .caret-inner {border-bottom-color: var(--bg3)}",
	"  .tweet .stats, .permalink .stats .avatar-row a:first-child, .ThreadedConversation-showMoreThreads {border-color: var(--bg4)}",
	"  .permalink.has-replies .inline-reply-tweetbox {background: var(--bg2); border-color: var(--bg2)}",
	"  .ThreadedConversation, .ThreadedConversation-moreReplies::after, .permalink .in-reply-to .tweet, .permalink .replies-to .tweet, .permalink .replies-to .ThreadedConversation--loneTweet .stream-tombstone-item {border-bottom-color: var(--bg3)}",
	"  .DMInboxItem {border-bottom-color: var(--bg4); background: var(--bg2)}",
	"  .DMInboxItem:hover {background: var(--bg3)  !important;}",
	"  .TwitterCard .PollXChoice-optionContainer .PollXChoice-choice--chart {background: var(--bg5)}",
	"  .message {background: var(--bg4) !important;}",
	"  .ProfileSidebar {background: var(--bg1); padding-bottom: 1px; padding-top: .5px; margin-top: 10px;}",
	"  .tweet-form .thumbnail-container {background: var(--bg3); box-shadow: inset 0 1px 0 var(--bg4)}",
	"  #global-tweet-dialog.tweet-showing .modal-header, #Tweetstorm-dialog.tweet-showing .modal-header, .block-dialog .block-section {border-color: var(--bg2)}",
	"  .DashUserDropdown.dropdown-menu .DashUserDropdown-userInfoLink:hover, .DashUserDropdown.dropdown-menu .DashUserDropdown-userInfoLink:focus, .DashUserDropdown.dropdown-menu .DashUserDropdown-userInfoLink:active {background: var(--bg3) !important;}",
	"  .input-daterange .input-group-addon {border: none; color: var(--colourF) !important;}",
	"  ",
	"  ",
	"  ",
	"  ",
	"  ",
	"  /* COLOUR F */",
	"  .flex-module-header h3, .WtfLargeCarouselStreamItem-title, .message .message-text, .global-nav .search-input, .typeahead a, .typeahead .fullname, .stats .stat-count strong, .ThreadedConversation--header, .DMActivity-title, .modal-header .modal-title, .modal .modal-tweet.disabled-links a strong, .modal .modal-tweet.disabled-links a:hover strong, .DMTypeaheadHeader, .MomentCapsuleSummary-title, .MomentCapsuleCover-title, .MomentCapsuleLikesFacepile-count, .MomentCapsuleLikesFacepile-countNum, .MomentUserByline-fullname, .MomentsPermalinkPage-relatedTitle, .ListCreationModule-title,  .ProfileHeading-title, .MomentCard-title, .PlayableMedia-title {color: var(--colourF) !important;}",
	"  .RelatedUsers-users .fullname {color: var(--colourF)}",
	"  .fullname, .QuoteTweet-fullname, .TweetImpressionsModule-heading, .message .close, .message .dismiss, .block-dialog .label-head, .phone-deletion-dialog .label-head, .block-dialog .label-title, .ProfileWarningTimeline-heading, .QuoteTweet .tweet-content, .QuoteTweet-text a, .QuoteTweet-text a:hover, .QuoteTweet-text a:focus, .QuoteTweet-text a:active, .QuoteTweet-text .pretty-link b, .QuoteTweet-text .pretty-link s, .QuoteTweet-text .pretty-link:hover b, .QuoteTweet-text .pretty-link:hover s, .QuoteTweet-text .pretty-link:focus b, .QuoteTweet-text .pretty-link:focus s, .QuoteTweet-text .pretty-link:active b, .QuoteTweet-text .pretty-link:active s, .SignupCallOut-title, .RelatedUsers-title, .AdaptiveSearchPage-moduleTitle, .search h1 {color: var(--colourF); font-weight: bold !important;}",
	"  ",
	"  /* COLOUR B */",
	"  .tweet p, div[contenteditable=\"true\"]:focus, div[contenteditable=\"true\"], .QuoteTweet-text, .TwitterCard .SummaryCard-content .TwitterCard-title, .TwitterCard .SummaryCard--small .SummaryCard-content p, .ActivityItem-displayText, .stream-end-inner button, .ProfileCard-bio, .ProfileHeading-toggleItem.is-active, .ProfileHeading-toggleItem.is-active:hover, .ProfileHeading-toggleItem.is-active:focus, .TweetImpressionsModule p, .ProfileHeaderCard-bio, .TwitterCard .PollXChoice-optionContainer .PollXChoice-choice--text span, .typeahead-items li > a, .typeahead strong, .dropdown-menu li > a, .dropdown-menu .dropdown-link, .hovercard.profile-card .bio-container, .MomentCapsuleSummary-description, .MomentCapsuleSubtitle, .MomentCapsuleItemTweet--withText .TweetTextSize, .MomentButton--gray, .MomentButton--gray:focus, .DMInboxItem-snippet, .TwitterCard .SummaryCard--large:not([data-card-breakpoints~=\"w300\"]) .SummaryCard-content p, .TwitterCard .SummaryCard--large .SummaryCard-content p, .MomentCapsuleItemTweet--withMedia .TweetTextSize, .MomentMakerMediaInlinePreview-noCropLabel, .TwitterCard .MomentCard-authorName, .Tombstone span, .Tombstone .Tombstone-action, .PlayableMedia-description, .PlayableMedia--vine .PlayableMedia-externalUrl, .advanced-search .td, .t1-select, input[type=\"file\"] {color: var(--colourB) !important;}",
	"",
	"",
	"",
	"",
	"",
	"",
	"  /*** CUSTOM STYLES ***/",
	"",
	"  /* Square Elements */",
	"  * {}",
	"",
	"  /* Fonts */",
	"  * {}",
	"  ",
	"  /* Trends*/",
	"  ",
	"  ",
	"  /* Simple Nav */",
	"  ",
	"  ",
	"  /* Background Image */",
	"  [dir=\"ltr\"].logged-in, #doc, #page-outer, html {background-position: center !important; background-image: url(https://pbs.twimg.com/media/Cv5VGcZUkAAKF6R.png:large) !important; background-size: cover !important; background-attachment: fixed !important;}",
	"  .ProfilePage .AppContent, #doc, #page-outer, html {background-position: center !important; background-image: url(https://pbs.twimg.com/media/Cv5VGcZUkAAKF6R.png:large) !important; background-size: cover !important; background-attachment: fixed !important;}",
	"",
	"  /* Custom Colours */"
].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
