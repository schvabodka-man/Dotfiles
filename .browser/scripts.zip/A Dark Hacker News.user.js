// ==UserScript==
// @name          A Dark Hacker News
// @namespace     http://userstyles.org
// @description	  A Dark Hacker News
// @author        Serkan Hosca
// @homepage      https://userstyles.org/styles/22794
// @include       http://news.ycombinator.com/*
// @include       https://news.ycombinator.com/*
// @include       http://*.news.ycombinator.com/*
// @include       https://*.news.ycombinator.com/*
// @run-at        document-start
// @version       0.20160118135158
// ==/UserScript==
(function() {var css = [
	"@namespace \"http://www.w3.org/1999/xhtml\";",
	"::-moz-selection {",
	"    background: #de935f !important;",
	"    color: #1d1f21 !important;",
	"  }",
	"  * {",
	"    font-family: sans-serif !important;",
	"    color: #c5c8c6;",
	"  }",
	"  body {",
	"    margin: 0;",
	"  }",
	"  .text-shadow {",
	"    text-shadow: black 0px 1px 3px !important;",
	"  }",
	"  td.default a {",
	"    text-shadow: black 0px 1px 3px !important;",
	"  }",
	"  font {",
	"    color: inherit !important;",
	"    font-family: inherit !important;",
	"    font-size: inherit !important;",
	"    text-shadow: black 0px 1px 3px !important;",
	"  }",
	"  td.default span.comhead a,",
	"  td.subtext a {",
	"    font-weight: bold;",
	"    text-shadow: black 0px 1px 3px !important;",
	"  }",
	"  body > center > table > tbody > tr:first-child > td {",
	"    background-color: #de935f !important;",
	"  }",
	"  body > center > table > tbody > tr:first-child > td * {",
	"    color: #1d1f21 !important;",
	"  }",
	"  .title {",
	"    font-size: 12pt;",
	"  }",
	"  .title a .sitestr {",
	"    color: #b5bd68 !important;",
	"  }",
	"  .title *,",
	"  .comment * {",
	"    color: #c5c8c6 !important;",
	"  }",
	"  .title a,",
	"  .comment a {",
	"    text-shadow: black 0px 1px 3px !important;",
	"    color: #c5c8c6 !important;",
	"  }",
	"  .title a:visited,",
	"  .comment a:visited {",
	"    color: #5e6360 !important;",
	"  }",
	"  .yclinks a {",
	"    color: #de935f !important;",
	"  }",
	"  .subtext a,",
	"  .subtext span {",
	"    text-shadow: black 0px 1px 3px !important;",
	"  }",
	"  .subtext span {",
	"    color: #cc6666 !important;",
	"  }",
	"  a[href^=item] {",
	"    color: #81a2be !important;",
	"  }",
	"  a[href^=user] {",
	"    color: #b294bb !important;",
	"  }",
	"  body,",
	"  body > center > table {",
	"    background-color: #1d1f21 !important;",
	"    width: 99% !important;",
	"  }"
].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
