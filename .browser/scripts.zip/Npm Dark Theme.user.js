// ==UserScript==
// @name          Npm Dark Theme
// @namespace     http://userstyles.org
// @description	  Dark theme for npmjs.com <br>
// @author        rosivanov
// @homepage      https://userstyles.org/styles/117106
// @include       http://npmjs.com/*
// @include       https://npmjs.com/*
// @include       http://*.npmjs.com/*
// @include       https://*.npmjs.com/*
// @run-at        document-start
// @version       0.20170326214205
// ==/UserScript==
(function() {var css = ".button,input[type=submit],.pagination a{background-color:#3b4354;border-color:#3b4354}.button:hover,input[type=submit]:hover,.pagination a:hover{background-color:#4c566c;border-color:#4c566c}body,.autocomplete-suggestions,.features-box,.calculator-module .calculator-module-premium-toggle{background:#2A303C}body>nav,body>nav a{background:#C35555}body>nav{border-color:#2A303C}body>header{border-bottom:1px solid transparent}#npm-search{background:transparent;border:1px solid #C35555}#npm-search:hover{border:1px solid #C35555}#site-search-submit{border-left:1px solid transparent}.autocomplete-suggestions{border-color:#864D4D}.autocomplete-selected{background:#C35555}#powered-by-constructor-io{background-color:#2A303C;border-color:#864D4D}h2.ruled,footer h3{border-bottom:2px solid #864D4D}.box li{border-bottom:2px solid #864D4D}form.star input[type=checkbox]+label:before{color:rgba(255,255,255,0.3)}code{background-color:#4D535F}.markdown>h2.deep-link a:before,.markdown h3.deep-link a:before,.markdown h4.deep-link a:before,.markdown h5.deep-link a:before,.markdown h6.deep-link a:before{color:#2A303C}.markdown td,.markdown th,.calculator-module .calculator-module-premium-toggle .calculator-module-premium-toggle-container{background:#4D535F}input,textarea{background-color:transparent}input[type=text],input[type=search],input[type=email],input[type=password],textarea{border:1px solid #C35555;background-color:#2A303C}.search-results .name{color:#ddd}.search-results .author{color:#4D535F}.search-results .keywords,.search-results .stats{color:#cb3837}body,h1,h2,h3,h4,h5,h6,input[type=text],input[type=search],input[type=email],input[type=password],.stat strong,.package-widget a.name,.package-widget .quiet a,.centered.ruled>a,.columnar h3 a,.columnar .links a,.package-name a,.markdown>h1 a,.markdown>h2 a,.markdown h3 a,.markdown h4 a,.markdown h5 a,.markdown h6 a,.markdown>h2,.markdown h3,.markdown h4,.markdown h5,.markdown h6,.markdown p,.markdown li,label,textarea,hgroup h1 a,hgroup h2 a,h1.undecorated a,h2.undecorated a,h3.undecorated a,.pagination a,.features-box .features-box-content ul,.css-dq7b6v,.css-1no28h1{color:#fff}.stat,.package-widget p,.package-widget .quiet,blockquote,.help-text,.description{color:#e0e0e0}a,.ad a.quiet,#npm-loves-you,.autocomplete-group,.stat:before,.package-widget a.name:before,.markdown>h2.deep-link a:hover:before,.markdown h3.deep-link a:hover:before,.markdown h4.deep-link a:hover:before,.markdown h5.deep-link a:hover:before,.markdown h6.deep-link a:hover:before,form p a:hover{color:#C35555}.highlight{background-color:#4D535F;color:#fff}.storage,.keyword,.storage.type,table th,table td,.css.support.property-name,pre.editor,pre code{color:#fff}.support.constant,.support.function,.support.type,.entity.other.attribute-name,.constant.language,.meta.structure.dictionary.json>.string.quoted.double.json,.meta.structure.dictionary.json>.string.quoted.double.json .punctuation.string{color:#BDCCF7}.string,.constant.numeric,.entity.name.function,.constant.character,.constant.other,.keyword.unit{color:#FB9DB5}.support.class,.variable,.entity.name.tag{color:#82C7C7}table tr:nth-child(2n) td{background:none}.npm-install:before,.autoselect-wrapper>input[type=text],.box,.sidebar a,.npm-install:before{color:#e0e0e0}.sidebar h3,.sidebar h3 a{color:#C35555}[data-page] header{background:#C35555}[data-page] nav,[data-page] nav a{background:#2A303C}[data-page] p.colophon{border-top:2px solid #C35555}[data-page] pre code{background:none repeat scroll 0% 0% #4D535F}[data-page] h1,[data-page] footer p,[data-page] p.colophon,[data-page] nav h2 a,[data-page] pre code,[data-page] code{color:#fff}[data-page] h1.subtitle,[data-page] nav .pages a{color:#e0e0e0}[data-page] h1 a,[data-page] h2 a,[data-page] h3 a,[data-page] h4 a,[data-page] h5 a,[data-page] h6 a{color:#C35555}";
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
