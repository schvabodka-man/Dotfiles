// ==UserScript==
// @name          Emacs Wiki - blacker
// @namespace     http://userstyles.org
// @description	  An edit of <a href="https://userstyles.org/styles/48932/emacs-wiki-black">Emacs Wiki - black</a>.
// @author        ylluminarious
// @homepage      https://userstyles.org/styles/124117
// @include       http://emacswiki.org/*
// @include       https://emacswiki.org/*
// @include       http://*.emacswiki.org/*
// @include       https://*.emacswiki.org/*
// @run-at        document-start
// @version       0.20160210003126
// ==/UserScript==
(function() {var css = [
	"body, h1 a:link {",
	"    background-color: #111 !important;",
	"    color: #ddd !important;",
	"  }",
	"  ",
	"  div.toc, div.color {",
	"    background-color: #222 !important;",
	"    color: gray !important;",
	"    padding-left: 1em !important;",
	"  }",
	"  ",
	"  a:link { color: #66a3ff !important; }",
	"  a:visited { color: #4d4dff !important; }",
	"  ",
	"  /*",
	"   Emacs Wiki - black",
	"   version 1.2",
	"   Copyright 2011 Kenneth W Foy, Jr",
	"   This work is licensed under a Creative Commons Attribution-",
	"   ShareAlike 3.0 Unported License.",
	"   http://creativecommons.org/licenses/by-sa/3.0/",
	" */",
	"  ",
	"  .logo, pre {",
	"    -webkit-filter: invert(100%) hue-rotate(180deg) !important;",
	"  }",
	"  ",
	"  #search, input, .edit.bar a, code, textarea {",
	"    background-color: black !important;",
	"    color: gray !important;",
	"  }",
	"  ",
	"  .edit.bar a {",
	"    background-image: none !important;",
	"  }"
].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
